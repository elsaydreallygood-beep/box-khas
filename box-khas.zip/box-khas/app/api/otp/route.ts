// app/api/otp/route.ts
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { sendPhoneOtp, sendEmailVerification, verifyOtp } from "@/lib/otp";

const sendSchema = z.object({
  channel: z.enum(["phone", "email"]),
  destination: z.string().min(3),
});

const verifySchema = z.object({
  destination: z.string().min(3),
  code: z.string().length(6),
});

// POST /api/otp  → إرسال رمز جديد
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }

  const body = await req.json();
  const parsed = sendSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "INVALID_INPUT" }, { status: 400 });
  }

  const { channel, destination } = parsed.data;
  const userId = (session.user as any).id;

  try {
    if (channel === "phone") {
      await sendPhoneOtp(userId, destination);
    } else {
      await sendEmailVerification(userId, destination);
    }
    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ error: "SEND_FAILED" }, { status: 500 });
  }
}

// PUT /api/otp  → التحقق من الرمز
export async function PUT(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }

  const body = await req.json();
  const parsed = verifySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "INVALID_INPUT" }, { status: 400 });
  }

  const userId = (session.user as any).id;
  const result = await verifyOtp(userId, parsed.data.destination, parsed.data.code);

  if (!result.success) {
    return NextResponse.json({ error: result.reason }, { status: 400 });
  }

  return NextResponse.json({ success: true });
}
